turno = str(input('Informe em que turno você estuda. Digite V para vespertino, M para matutino ou N para noturno, :' ))
if turno =='M':
  print('Bom Dia!')

elif turno == 'V':
  print('Boa Tarde!')

elif turno == 'N':
  print('Boa Noite!')

else:
  print('Valor Invalido!')
