x=0
crime1 = input('Telefonou para a vítima? s/n:')
if crime1 == 's':
 x=x+1

 
crime2 = input('Esteve no local do crime? s/n:')
if crime2 == 's':
 x=x+1

 
crime3 = input('Mora perto da vitima? s/n:')
if crime3 == 's':
 x=x+1

 
crime4 = input('Devia para a vitima? s/n:')
if crime4 == 's':
 x=x+1

 
crime5 = input('Já trabalhou perto da vitima? s/n:')
if crime5 == 's':
 x=x+1

if x==2:
 print('Suspeita')

elif x==3 or x==4:
 print('Cúmplice')
 
elif x==5:
 print('Assassino')

else:
 print('Inocente')
