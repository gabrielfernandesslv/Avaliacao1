numero = int
numero = input('Informe um numero:')
print(numero [::-1])
