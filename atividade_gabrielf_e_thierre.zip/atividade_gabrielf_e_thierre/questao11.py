n =int(input("Digite um número inteiro de 1 a 10: "))
x=1
if n>=1 and n<=10:
    while x<=10:
        mult=n*x
        print (n," X ", x," = ", mult)
        x=x+1

else:
    print("Apenas números de 1 a 10")

