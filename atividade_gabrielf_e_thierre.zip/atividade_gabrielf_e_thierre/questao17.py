x=0
n=int
n = input('Informe um número inteiro:')
for i in n :
     x= x+1

print('A quantidade de digitos desse número inteiro é:' , x)
