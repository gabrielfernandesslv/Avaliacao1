tf = float(input("Digite a temperatura em Fahrenheit: "))
conversao = (5 * (tf - 32) / 9)
print ('Em graus celsius, essa temperatura é: %.2f' %conversao)
 
