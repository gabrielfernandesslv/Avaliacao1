metros = float(input('Informe tamanho em metros quadrados da área que será pintada:'))

litros = metros/ 3
latas = litros / 18
total = latas * 80

print('Você irá usar' , latas , 'latas de tinta ')
print('O valor total é de: R$ ' , total)
