data= int(input('Informe uma data:'))
mes= int(input('Informe um mes:'))
ano= int(input('Informe um ano:'))

x=0
meses= ['posicao0', 'janeiro', 'fevereiro', 'março',' abril',' maio',' junho', 'julho', 'agosto',' setembro','outubro','novenbro', 'dezembro']
for i in range(13):
    if data>31 or data<1:
        break
    elif mes>12 or mes<1:
        break
    elif i == mes:
        print(data," de ",meses[i], " de ", ano )
        x=x+1
