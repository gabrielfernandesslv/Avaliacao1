a= str(input('Informe o primeiro argumento:'))
b= str(input('Informe o segundo argumento:'))
c= str(input('Informe o terceiro argumento:'))
print('A soma dos tres argumentos é:' , a+b+c)
