x = float(input('Informe o valor  que recebe por hora:'))
y = int(input('Informe quantas horas trabalha por dia :'))

sb = x * y

ir = sb * 0.11

inss = sb* 0.08

sind = sb* 0.05

sl = sb - ir - inss - sind

totalapagar =  ir+inss+sind

print('O salario bruto é:' , sb)
print('O INSS é:' , inss)
print('O Sindicato é:' , sind)
print('O Salario Liquido é:' , sl)
print('O Imposto Total é:' , totalapagar)


