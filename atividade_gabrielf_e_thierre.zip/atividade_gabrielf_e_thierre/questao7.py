sal = int(input('Informe o seu salario:'))

if sal<= 280:
 saltotal = sal*0.2 +sal
 print('O salario antes do reajuste:' , sal)
 print('O salario com o aumento aplicado de : 20%')
 print('O valor do aumento é :' , sal*0.2)
 print('O salario após o aumento :' , saltotal)

 
elif sal>=280 and sal<=700:
 saltotal = sal*0.15 +sal
 print('O salario antes do reajuste:' , sal)
 print('O salario com o aumento aplicado de : 15%')
 print('O valor do aumento é :' , sal*0.15)
 print('O salario após o aumento :' , saltotal)


elif sal>=700 and sal<=1500:
 saltotal = sal*0.1 +sal
 print('O salario antes do reajuste:' , sal)
 print('O salario com o aumento aplicado de : 10%')
 print('O valor do aumento é :' , sal*0.1)
 print('O salario após o aumento :' , saltotal)


elif sal> 1500:
 saltotal = sal*0.05 +sal
 print('O salario antes do reajuste:' , sal)
 print('O salario com o aumento aplicado de : 5%')
 print('O valor do aumento é :' , sal*0.05)
 print('O salario após o aumento :' , saltotal)



 



