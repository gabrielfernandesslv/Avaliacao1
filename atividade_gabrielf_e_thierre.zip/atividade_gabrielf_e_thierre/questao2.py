prompt_1 = "Digite o primeiro numero : "
prompt_2 = "Digite o segundo numero : "
prompt_3 = "Digite o terceiro numero : "

a = int(input(prompt_1))
b = int(input(prompt_2))
c = float(input(prompt_3))

#letra a
p = (2*a)*(b/2)
print ('O produto do dobro do primeiro com metade do segundo é: ', p)

#letra b
s = (3*a)+c
print ('A soma do triplo do primeiro com o terceiro é: ', s)

#letra c
potencia = c**3
print ('O terceiro elevado ao cubo é: ', potencia)


           
