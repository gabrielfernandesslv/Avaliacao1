kgmorango=int(input("Quantidade em quilos de morango: "))
kgmaca=int(input("Quantidade em quilos de maçã: "))
if kgmorango<=5:
    valormorango = kgmorango * 2.5
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormorango)

elif kgmorango>5 or kgmorango >6 or kgmorango >7 or kgmorango >=8:
    valormorango = kgmorango *2.2
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormorango)

elif kgmorango >8 :
    descontovalormorango =(kgmorango *2.2)*0.1
    valormorango = (valormorango * 2.2) - descontovalormorango
    print("O valor a ser pago de morango pelo cliente é: ","%.2f" % valormorango)

if kgmaca<=5:
    valormaca=kgmaca*1.8
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)

elif kgmaca>5 or kgmaca>6 or kgmaca>7 or kgmaca>=8:
    valormaca=kgmaca*1.5
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)

elif kgmaca > 8 :
    descontovalormaca =(kgmaca *1.5)*0.1
    valormaca = (valormorango * 1.5) - descontovalormaca
    
    print("O valor a ser pago de maçã pelo cliente é: ","%.2f" % valormaca)


