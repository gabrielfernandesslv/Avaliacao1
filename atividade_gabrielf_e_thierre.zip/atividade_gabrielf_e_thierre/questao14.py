x=0
espçvogal = "aeiou "
frase=str(input("Digite uma frase: "))
for i in frase:
    if i in espçvogal:
        x=x+1
print(x)        
