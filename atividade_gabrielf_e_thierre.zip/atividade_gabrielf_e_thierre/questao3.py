prompt_1 = 'Informe o sexo: '
prompt_2 = 'Informe a altura: '


sexo = str(input(prompt_1))
altura = float(input(prompt_2))

if (sexo == 'm') :
          pesoIM = (72.7*altura)-58
          print ('Senhor, o seu peso ideal é: ', pesoIM)
           
elif (sexo == 'f') : 
            pesoIF = (62.1*altura) - 44.7
            print ('Senhora, o seu peso ideal é :', pesoIF)

else :
            print ('Sexo Inválido')
           
