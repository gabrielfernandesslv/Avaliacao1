nome = input('Informe um nome de usuário:')
senha = input('Informe uma senha de usuario:')

while senha == nome:
     senha = input('Digite uma nova senha que seja diferente do usuário:')

print("Nome: %s, Senha: %s" %(nome, senha))

