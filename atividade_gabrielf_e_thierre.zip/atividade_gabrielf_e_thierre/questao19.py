n= float(input('Informe um número:'))
if n >0:
  print('P')
if n<0:
  print('N')
if n==0:
 print('Z')
